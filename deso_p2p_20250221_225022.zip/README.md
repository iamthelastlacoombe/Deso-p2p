# DeSo P2P Application

A Python-based P2P application for Deso coin with basic networking capabilities and iOS client.

## Project Structure

```
├── ios/
│   ├── BUILD.md
│   ├── CODEMAGIC_SETUP.md
│   ├── DeSoP2P.swift
│   ├── NetworkManager.swift
│   ├── Transaction.swift
│   └── exportOptions.plist
├── .gitignore
├── README.md
├── SSH_SETUP.md
├── cli.py
├── codemagic.yaml
├── main.py
├── network.py
├── node.py
├── transaction.py
└── utils.py
```

## Features

- P2P networking with node discovery
- Transaction creation and verification
- iOS client with SwiftUI interface
- Secure transaction signing

## Setup Instructions

1. Create a new repository on GitHub
2. Create each file in the structure shown above
3. Copy the contents of each file from the provided source
4. Install required Python packages:
   ```
   pip install cryptography
   ```

## Running the Application

```bash
python main.py
```

For iOS build instructions, see [iOS Build Guide](ios/BUILD.md).

## License

This project is licensed under the MIT License - see the LICENSE file for details.