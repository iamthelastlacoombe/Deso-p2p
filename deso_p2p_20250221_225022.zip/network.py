import asyncio
import json
from typing import List, Set
import logging

class NetworkManager:
    def __init__(self):
        self.known_nodes: Set[tuple] = set()
        self.logger = logging.getLogger(__name__)

    async def discover_nodes(self, bootstrap_nodes: List[tuple]):
        """Discover nodes using bootstrap nodes"""
        for node in bootstrap_nodes:
            try:
                reader, writer = await asyncio.open_connection(node[0], node[1])

                # Send discovery request
                message = {
                    'type': 'discover',
                }
                writer.write(json.dumps(message).encode() + b'\n')
                await writer.drain()

                # Get response
                data = await reader.readline()
                if data:
                    response = json.loads(data.decode())
                    if response['type'] == 'nodes':
                        for node_info in response['nodes']:
                            self.known_nodes.add((node_info['host'], node_info['port']))

                writer.close()
                await writer.wait_closed()

            except Exception as e:
                self.logger.error(f"Failed to discover nodes from {node}: {str(e)}")

    async def ping_node(self, host: str, port: int) -> bool:
        """Ping a node to check if it's alive"""
        try:
            reader, writer = await asyncio.open_connection(host, port)

            message = {
                'type': 'ping',
            }
            writer.write(json.dumps(message).encode() + b'\n')
            await writer.drain()

            data = await reader.readline()
            writer.close()
            await writer.wait_closed()

            if not data:
                return False

            response = json.loads(data.decode())
            return response.get('type') == 'pong'

        except Exception:
            return False

    async def maintain_network(self):
        """Periodically check and maintain network connections"""
        while True:
            dead_nodes = set()
            for node in self.known_nodes:
                if not await self.ping_node(node[0], node[1]):
                    dead_nodes.add(node)

            # Remove dead nodes
            self.known_nodes -= dead_nodes

            if dead_nodes:
                self.logger.info(f"Removed {len(dead_nodes)} dead nodes")

            await asyncio.sleep(60)  # Check every minute